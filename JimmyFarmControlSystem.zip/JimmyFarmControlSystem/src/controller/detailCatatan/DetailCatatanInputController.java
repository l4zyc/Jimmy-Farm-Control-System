package controller.detailCatatan;

import controller.ControllerData;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import util.Connect;
import view.CatatanDetail.DetailCatatanInputView;

public class DetailCatatanInputController extends ControllerData{ 
	
	private DetailCatatanInputView view; 
	private Connect connect = Connect.getInstance(); 
	
	public DetailCatatanInputController(DetailCatatanInputView detailcatataninputview) { 
		this.view = detailcatataninputview; 
		
	}
	
	protected void SetOnActionSave() { 
		view.getSave().setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				Integer KematianJantan = Integer.parseInt(view.getKematianJantanTF().getText().trim()); 
				Integer KematianBetina = Integer.parseInt(view.getKematianBetinaTF().getText().trim()); 
				String KodePakan = view.getKodeObatCB().getValue().toString(); 
				Integer JumlahPakan = Integer.parseInt(view.getJumlahPakanTF().getText().trim()); 
				String KodeObat = view.getKodeObatCB().getValue().toString(); 
				Integer JumlahObat = Integer.parseInt(view.getJumlahObatTF().getText().trim()); 
				Integer JumlahProduksiTelur = Integer.parseInt(view.getJumlahProduksiTelurTF().getText().trim()); 
				Integer BiayaVariable = Integer.parseInt(view.getBiayaVariabelTF().getText().trim()); 
				String KomentarKematian = view.getKomentarKematianTA().getText(); 
				
				
				
			} 
			
		});
		
		
	}
	
}
