package view.MasterKandang;

import controller.masterKandang.MasterKandangController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.MsKandang;
import util.Data;
import view.TableViewTemplate;

public class MasterKandangView extends TableViewTemplate{

	private Scene scene;
	private Stage KandangStage;
	
	public MasterKandangView() { 
		setSideBar();
		init();
		arrangeComponent();
		KandangStage = new Stage();
		
		KandangStage.setMaximized(true);
		KandangStage.setScene(scene);
		KandangStage.setTitle("Jimmy Farm Control System");
		KandangStage.show();
		
		new MasterKandangController(this);
	}
	
	Label CatatanHarianLbl, JFCS; 
	TableView<MsKandang> TableKandang;
	TableColumn<MsKandang, String> KodeKandangTC, LokasiTC;
	Button Update, Delete, InputData; //button
	HBox ButtonContainer;
	
	@Override
	public void init() {
		// TODO Auto-generated method stub
		mainLayout = new BorderPane();
		TableLayout = new BorderPane();
		scene = new Scene(mainLayout);  
		
		//Column Kode Kandang
		TableKandang = new TableView<MsKandang>();
		KodeKandangTC = new TableColumn<MsKandang, String>("Kode Kandang");
		KodeKandangTC.setCellValueFactory(new PropertyValueFactory<MsKandang, String>("KodeKandang")); 
				
		//Column Nama Kandang 
		LokasiTC = new TableColumn<MsKandang, String>("Lokasi");
		LokasiTC.setCellValueFactory(new PropertyValueFactory<MsKandang, String>("Lokasi"));
				
		TableKandang.getColumns().addAll(KodeKandangTC, LokasiTC); 
		TableKandang.getItems().addAll(data.getMasterKandangData());
		
		//Bagian button update 
		Update = new Button("Update"); 
		Update.setFont(Font.font("Inter", 20)); 
		Update.setMinWidth(50); 
										
		//Bagian button Delete 
		Delete = new Button("Delete"); 
		Delete.setFont(Font.font("Inter", 20)); 
		Delete.setMinWidth(50); 
										
		//Bagian button Input Data 
		InputData = new Button("Input Data"); 
		InputData.setFont(Font.font("Inter", 20));
		InputData.setMinWidth(50);
										
		//Bagian Menubar
										
		ButtonContainer = new HBox();
						
						
		JFCS = new Label("Jimmy Farm Control System");
		
		KodeKandangTC.prefWidthProperty().bind(TableKandang.widthProperty().multiply(0.15));
		LokasiTC.prefWidthProperty().bind(TableKandang.widthProperty().multiply(0.15));
		
		TableKandang.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		
		KodeKandangTC.setStyle("-fx-alignment: CENTER;");
		LokasiTC.setStyle("-fx-alignment: CENTER;");
		
	}

	@Override
	public void arrangeComponent() {
		// TODO Auto-generated method stub
		
		HBox leftBtnContainer = new HBox();
		leftBtnContainer.getChildren().addAll(InputData, Update);
		
		ButtonContainer.getChildren().addAll(leftBtnContainer, Delete);
		
		CatatanHarianLbl = new Label("Master Kandang");
	
		TableLayout.setTop(CatatanHarianLbl);
		TableLayout.setCenter(TableKandang);
		TableLayout.setBottom(ButtonContainer);
		
		BorderPane.setMargin(TableKandang, new Insets(15, 0, 15, 0));
		BorderPane.setAlignment(CatatanHarianLbl, Pos.CENTER);
		CatatanHarianLbl.setFont(Font.font("Arial", FontWeight.BOLD, 30));
		
		ButtonContainer.setSpacing(10);
		
		TableLayout.setPadding(new Insets(80));
		getMasterKandangLbl().setFont(Font.font("Arial", FontWeight.BOLD, 20));
		
		mainLayout.setTop(getMb());
		mainLayout.setCenter(TableLayout);
		mainLayout.setLeft(getSideBar());
	}

	public Scene getScene() {
		return scene;
	}

	public Stage getKandangStage() {
		return KandangStage;
	}

	public Data getData() {
		return data;
	}


	public Label getCatatanHarianLbl() {
		return CatatanHarianLbl;
	}

	public Label getJFCS() {
		return JFCS;
	}

	public TableView<MsKandang> getTableKandang() {
		return TableKandang;
	}

	public TableColumn<MsKandang, String> getKodeKandangTC() {
		return KodeKandangTC;
	}

	public TableColumn<MsKandang, String> getLokasiTC() {
		return LokasiTC;
	}

	public Button getUpdate() {
		return Update;
	}

	public Button getDelete() {
		return Delete;
	}

	public Button getInputData() {
		return InputData;
	}

	public HBox getButtonContainer() {
		return ButtonContainer;
	}

	public void setScene(Scene scene) {
		this.scene = scene;
	}

	public void setKandangStage(Stage kandangStage) {
		KandangStage = kandangStage;
	}

	public void setData(Data data) {
		this.data = data;
	}


	public void setCatatanHarianLbl(Label catatanHarianLbl) {
		CatatanHarianLbl = catatanHarianLbl;
	}

	public void setJFCS(Label jFCS) {
		JFCS = jFCS;
	}

	public void setTableKandang(TableView<MsKandang> tableKandang) {
		TableKandang = tableKandang;
	}

	public void setKodeKandangTC(TableColumn<MsKandang, String> kodeKandangTC) {
		KodeKandangTC = kodeKandangTC;
	}

	public void setLokasiTC(TableColumn<MsKandang, String> lokasiTC) {
		LokasiTC = lokasiTC;
	}

	public void setUpdate(Button update) {
		Update = update;
	}

	public void setDelete(Button delete) {
		Delete = delete;
	}

	public void setInputData(Button inputData) {
		InputData = inputData;
	}

	public void setButtonContainer(HBox buttonContainer) {
		ButtonContainer = buttonContainer;
	}

	
	
}
